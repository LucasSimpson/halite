from version_5 import run_bot

run_bot.run()

